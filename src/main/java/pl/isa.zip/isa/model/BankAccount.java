package pl.isa.model;

public class BankAccount {
}
