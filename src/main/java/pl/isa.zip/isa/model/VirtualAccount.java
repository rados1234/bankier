package pl.isa.model;

public class VirtualAccount {
}
