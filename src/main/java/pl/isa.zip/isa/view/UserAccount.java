package pl.isa.view;
// jira task: https://jira.is-academy.pl/browse/JJDZR14BA-5


public class UserAccount {
}
